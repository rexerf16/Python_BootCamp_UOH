# printing a "Hello world" as as a string output
print("Hello World")
