# *2 this is a comment

print("Hello")

'''
this is a long
comment
'''
