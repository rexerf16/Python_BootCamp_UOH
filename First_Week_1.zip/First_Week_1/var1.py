# *4 printing varibals besides strings
name = "Mohammed"
age = "23"
city = "hail"
major = "CS"
print("My name is "+name+" and i am "+age)
print("i live in "+city)
print("i study "+major)
