# *4 dealing with varibals as numbers
a = 8
b = 5
ab = a+b
print(a)
print(b)
print(ab)
print(a+b)
print(a-b)
print(a*b)
print(a/b)
print(a, b)
